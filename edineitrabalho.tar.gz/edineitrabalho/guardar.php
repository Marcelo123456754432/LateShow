<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/all.css">
    <link rel="stylesheet" href="style.css"> 
</head>
<body>
    <table class="table table-striped table-hover">
        <thead>
            <th>Nome</th>
            <th>Telefone</th>
            <th>Data de nascimento</th>
            <th>Email</th>
          
        </thead>




        
<?php
    try {


        
        require('conexao.php');
        // A variável $pdo, usada a seguir, está vindo do conexao.php

        

        $consulta = $pdo->prepare("SELECT * FROM cadastro");
        $consulta->execute();

        $cadastro = $consulta->fetchAll();
        
        foreach($cadastro as $linha) {
            echo "<tr>
                    <td>{$linha["nome"]}</td>
                    <td>{$linha["telefone"]}</td>
                    <td>{$linha[" nascimento"]}</td>
                    <td>{$linha["email"]}</td>
                    
                </tr>";
        }

    } catch(Exception $e) {
        die("Erro de banco de dados: " . $e->getMessage());
    }    
?>    
    </table>
    <p><a class="btn btn-success" href="index.php">Voltar ao início.</a></p>
    
    <script src="vendor/popper.min.js"></script>
    <script src="vendor/jquery-3.3.1.slim.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>