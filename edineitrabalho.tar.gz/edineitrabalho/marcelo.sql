-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema edineibd
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `edineibd` ;

-- -----------------------------------------------------
-- Schema edineibd
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `edineibd` DEFAULT CHARACTER SET utf8 ;
USE `edineibd` ;

-- -----------------------------------------------------
-- Table `edineibd`.`cadastro`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `edineibd`.`cadastro` (
  `idcadastro` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `nascimento` VARCHAR(45) NOT NULL DEFAULT '',
  `telefone` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idcadastro`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
