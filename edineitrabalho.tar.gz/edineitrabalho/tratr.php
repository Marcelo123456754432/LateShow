<?php
    //var_dump($_POST);
    $nome = $_POST['nome'];
   $nascimento = $_POST['nascimento'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
   

    

    try {
        include_once('conexao.php');
        // A variável $pdo, usada a seguir, está vindo do conexao.php

        $consulta = $pdo->prepare("INSERT INTO cadastro
        (nome,   nascimento,  telefone, email)
        VALUES
        (:nome, :nascimento,  :telefone, :email)");
        
        $consulta->bindValue(":nome", $nome);
        $consulta->bindValue(":nascimento", $nascimento);
        $consulta->bindValue(":telefone", $telefone);
        $consulta->bindValue(":email", $email);
        $consulta->execute();

    } catch(Exception $e) {
        die("Erro de banco de dados: " . $e->getMessage());
    }

    header('location: index.php');
?>